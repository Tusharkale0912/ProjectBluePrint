from django.apps import AppConfig


class ProjectUploaderConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'project_uploader'
